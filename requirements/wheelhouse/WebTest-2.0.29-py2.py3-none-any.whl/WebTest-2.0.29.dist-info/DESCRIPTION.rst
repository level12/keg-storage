=======
WebTest
=======

This wraps any WSGI application and makes it easy to send test
requests to that application, without starting up an HTTP server.

This provides convenient full-stack testing of applications written
with any WSGI-compatible framework.

Full docs can be found at https://webtest.readthedocs.io/en/latest/


