from waitress.runner import run  # pragma nocover
run()  # pragma nocover
