intervals
---------

Python tools for handling intervals (ranges of comparable objects).


