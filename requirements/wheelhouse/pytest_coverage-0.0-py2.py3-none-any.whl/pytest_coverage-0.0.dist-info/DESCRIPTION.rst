Use `pytest-cover <https://pypi.python.org/pypi/pytest-cover/>`_ instead.


