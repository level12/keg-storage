infinity
--------

All-in-one infinity value for Python. Can be compared to any object.


